/**
 * 
 */
/**
 * 
 */
module SmartParkingFinderSystem {
	requires java.sql;
	requires java.desktop;
}
package parking.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {
        Connection con = null;

        try {
            // Database URL
            String url = "jdbc:mysql://localhost:3306/parking_system";
            String user = "root";
            String password = "mysql"; 

            con = DriverManager.getConnection(url, user, password);

            System.out.println("Database Connected Successfully");

        } catch (Exception e) {
            System.out.println("Connection Failed");
            e.printStackTrace();
        }

        return con;
    }
}